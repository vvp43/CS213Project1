package eventcalendar;



/**
 * This class is the main driver, which executes the whole program
 * @author Seth Yeh, Vinh Pham
 */


public class MainDriver {
    public static void main(String[] args) {
        new EventOrganizer().run();

    }
}
